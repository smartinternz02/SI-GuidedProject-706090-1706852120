<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Your Profiles</name>
   <tag></tag>
   <elementGuidId>a6b6d59a-ad5f-4caa-afeb-3ce390300646</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div/div/div[4]/div/a/div/div/div/div[2]/h2</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>29de7f40-eb79-44ad-a48c-d42d038f1fca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-spacing-none ya-card__heading--rich a-text-normal</value>
      <webElementGuid>8f43daf8-d503-4b19-b2b6-94fa121df2eb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    Your Profiles
                </value>
      <webElementGuid>cbb15663-1f81-4b7d-84bd-aa393512b806</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[@class=&quot;a-container&quot;]/div[@class=&quot;a-section ya-personalized&quot;]/div[@class=&quot;ya-card-row&quot;]/div[@class=&quot;ya-card-cell&quot;]/a[@class=&quot;ya-card__whole-card-link&quot;]/div[@class=&quot;a-box ya-card--rich&quot;]/div[@class=&quot;a-box-inner&quot;]/div[@class=&quot;a-row&quot;]/div[@class=&quot;a-column a-span9 a-span-last&quot;]/h2[@class=&quot;a-spacing-none ya-card__heading--rich a-text-normal&quot;]</value>
      <webElementGuid>8c498a36-4225-418f-b242-07640b8f51dd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div/div/div[4]/div/a/div/div/div/div[2]/h2</value>
      <webElementGuid>71a64212-77c6-4d31-928d-da66e73a308c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/a/div/div/div/div[2]/h2</value>
      <webElementGuid>abca192a-c0a1-4590-a477-f97b920e8d61</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = '
                    Your Profiles
                ' or . = '
                    Your Profiles
                ')]</value>
      <webElementGuid>4be434fb-1d24-4286-9335-f04822593db4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
