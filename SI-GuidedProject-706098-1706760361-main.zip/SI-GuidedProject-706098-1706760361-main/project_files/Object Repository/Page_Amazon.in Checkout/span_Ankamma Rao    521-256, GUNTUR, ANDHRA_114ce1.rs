<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Ankamma Rao    521-256, GUNTUR, ANDHRA_114ce1</name>
   <tag></tag>
   <elementGuidId>d4aaa169-b050-498e-a261-2033e67257bc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='address-list']/div/div/div/fieldset/div[2]/span/div/label/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>14b3dbd9-45df-4564-8ef1-73a18df6b28b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-label a-radio-label</value>
      <webElementGuid>7188df2f-5e0f-4ba1-bf8f-44457791576e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
      

            Ankamma Rao
    
521-256, GUNTUR, ANDHRA PRADESH, 522017, India


        
          
            Edit address
            
          
        
         
|
        
            
                Add delivery instructions
            
        



        


               



      </value>
      <webElementGuid>3e622d04-08fe-4315-a4b5-feac0234fb34</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;address-list&quot;)/div[@class=&quot;a-box-group a-spacing-small&quot;]/div[@class=&quot;a-box&quot;]/div[@class=&quot;a-box-inner&quot;]/fieldset[1]/div[@class=&quot;a-row address-row&quot;]/span[@class=&quot;a-declarative&quot;]/div[@class=&quot;a-radio&quot;]/label[1]/span[@class=&quot;a-label a-radio-label&quot;]</value>
      <webElementGuid>931607bd-5a97-487e-bd33-1033b820192d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='address-list']/div/div/div/fieldset/div[2]/span/div/label/span</value>
      <webElementGuid>dc094a7b-6241-4a4e-a902-47352b128c9c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/span/div/label/span</value>
      <webElementGuid>93a0742e-09bc-4b23-b3db-295938b55b9d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
      

            Ankamma Rao
    
521-256, GUNTUR, ANDHRA PRADESH, 522017, India


        
          
            Edit address
            
          
        
         
|
        
            
                Add delivery instructions
            
        



        


               



      ' or . = '
      

            Ankamma Rao
    
521-256, GUNTUR, ANDHRA PRADESH, 522017, India


        
          
            Edit address
            
          
        
         
|
        
            
                Add delivery instructions
            
        



        


               



      ')]</value>
      <webElementGuid>7e8e4f32-e393-49f0-b4e1-3bd128aeb5eb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
