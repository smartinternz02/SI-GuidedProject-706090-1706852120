<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_4        Items and delivery</name>
   <tag></tag>
   <elementGuidId>1fd3b6e9-9e40-43d0-a2ff-8cad9076a31a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.a-column.a-span12 > h3.a-color-secondary</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='revieworder']/div[3]/div/div/div/h3</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>dab67573-3067-4e55-b9d8-ecddd66c2b33</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-color-secondary</value>
      <webElementGuid>32c01c98-3cc3-4a39-acdd-2d1498cf5abe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        4
        Items and delivery
      </value>
      <webElementGuid>f4f02c9a-f2be-497a-8819-0b05c5228eaa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;revieworder&quot;)/div[@class=&quot;a-row panel-content&quot;]/div[@class=&quot;a-section&quot;]/div[@class=&quot;a-row&quot;]/div[@class=&quot;a-column a-span12&quot;]/h3[@class=&quot;a-color-secondary&quot;]</value>
      <webElementGuid>f6e7fa13-bb84-451b-b0bc-97a0042ac335</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='revieworder']/div[3]/div/div/div/h3</value>
      <webElementGuid>8c832db1-f682-49cb-b371-e0c862b775bf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div/h3</value>
      <webElementGuid>0d1cba4d-290b-4528-9748-36db3c66f51c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = '
        4
        Items and delivery
      ' or . = '
        4
        Items and delivery
      ')]</value>
      <webElementGuid>128079c4-a184-40db-a86b-6825dffb6986</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
