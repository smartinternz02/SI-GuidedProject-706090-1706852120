<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_3                Offers</name>
   <tag></tag>
   <elementGuidId>6c7e8ec1-c342-4af7-9e42-3475a7a3d643</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h3.a-color-secondary</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='prime']/div[3]/div[2]/div/h3</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>08a9c1b5-50a2-44b7-8cd6-f56c9b9787ed</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-color-secondary</value>
      <webElementGuid>0b7eeca8-5ecb-46f0-94e6-d18fed66b487</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        3
        
        Offers
      </value>
      <webElementGuid>a400eccb-2da0-4b68-9449-45eeb42703f8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;prime&quot;)/div[@class=&quot;a-row panel-content&quot;]/div[@class=&quot;a-row a-spacing-small&quot;]/div[@class=&quot;a-column a-span10&quot;]/h3[@class=&quot;a-color-secondary&quot;]</value>
      <webElementGuid>0533d003-63ee-45ab-b407-a4b0c274abda</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='prime']/div[3]/div[2]/div/h3</value>
      <webElementGuid>6e1d43d1-d303-4651-9588-9cde7e9c1263</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/h3</value>
      <webElementGuid>95b00899-4090-4163-bb71-eef82f4c1c22</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = '
        3
        
        Offers
      ' or . = '
        3
        
        Offers
      ')]</value>
      <webElementGuid>86196d9a-7878-4c19-99dd-040455d02763</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
